package com.cast.bean;

import java.util.Date;

public class Movie {
    private int movieid;
    private String moviename;
    private String movietype;
    private int movienum;
    private int movietime;
    private Date moviedate;
    private float movieprice;

    public String getMoviename() {
        return moviename;
    }

    public void setMoviename(String moviename) {
        this.moviename = moviename;
    }

    public String getMovietype() {
        return movietype;
    }

    public void setMovietype(String movietype) {
        this.movietype = movietype;
    }

    public int getMovietime() {
        return movietime;
    }

    public void setMovietime(int movietime) {
        this.movietime = movietime;
    }

    public Date getMoviedate() {
        return moviedate;
    }

    public void setMoviedate(Date moviedate) {
        this.moviedate = moviedate;
    }

    public float getMovieprice() {
        return movieprice;
    }

    public void setMovieprice(float movieprice) {
        this.movieprice = movieprice;
    }

    public int getMovienum() {
        return movienum;
    }

    public void setMovienum(int movienum) {
        this.movienum = movienum;
    }

    public int getMovieid() {
        return movieid;
    }

    public void setMovieid(int movieid) {
        this.movieid = movieid;
    }

    @Override
    public String toString() {
        return "Movie{" +
                "movieid=" + movieid +
                ", moviename='" + moviename + '\'' +
                ", movietype='" + movietype + '\'' +
                ", movienum=" + movienum +
                ", movietime=" + movietime +
                ", moviedate=" + moviedate +
                ", movieprice=" + movieprice +
                '}';
    }
}
