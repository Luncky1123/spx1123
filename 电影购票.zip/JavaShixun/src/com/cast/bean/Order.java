package com.cast.bean;

import java.util.Date;

public class Order {
    private int orderid;
    private String username;
    private String moviename;
    private String movietype;
    private float movieprice;
    private int movienum;
    private float totalprice;
    private Date ordertime;

    public int getOrderid() {
        return orderid;
    }

    public void setOrderid(int orderid) {
        this.orderid = orderid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getMoviename() {
        return moviename;
    }

    public void setMoviename(String moviename) {
        this.moviename = moviename;
    }

    public String getMovietype() {
        return movietype;
    }

    public void setMovietype(String movietype) {
        this.movietype = movietype;
    }

    public float getMovieprice() {
        return movieprice;
    }

    public void setMovieprice(float movieprice) {
        this.movieprice = movieprice;
    }

    public int getMovienum() {
        return movienum;
    }

    public void setMovienum(int movienum) {
        this.movienum = movienum;
    }

    public float getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(float totalprice) {
        this.totalprice = totalprice;
    }

    public Date getOrdertime() {
        return ordertime;
    }

    public void setOrdertime(Date ordertime) {
        this.ordertime = ordertime;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderid=" + orderid +
                ", username='" + username + '\'' +
                ", moviename='" + moviename + '\'' +
                ", movietype='" + movietype + '\'' +
                ", movieprice=" + movieprice +
                ", movienum=" + movienum +
                ", totalprice=" + totalprice +
                ", ordertime=" + ordertime +
                '}';
    }
}
