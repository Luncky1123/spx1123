package com.cast.bean;

public class Salebean {
    private String movietype;
    private int total_num;
    private float totalprice;

    public String getMovietype() {
        return movietype;
    }

    public void setMovietype(String movietype) {
        this.movietype = movietype;
    }

    public float getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(float totalprice) {
        this.totalprice = totalprice;
    }

    public int getTotal_num() {
        return total_num;
    }

    public void setTotal_num(int total_num) {
        this.total_num = total_num;
    }

    @Override
    public String toString() {
        return "Salebean{" +
                "movietype='" + movietype + '\'' +
                ", totalprice=" + totalprice +
                '}';
    }
}
