package com.cast.bean;

import java.text.SimpleDateFormat;
import java.util.Date;

public class User {
    private int userid;
    private String username;
    private String password;
    private String tel;
    private float balance;
    private Date date;
    private int indentify;

    public int getIndentify() {
        return indentify;
    }

    public void setIndentify(int indentify) {
        this.indentify = indentify;
    }

    public Date getDate() {

        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }
    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "User{" +
                "userid=" + userid +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", tel='" + tel + '\'' +
                ", balance=" + balance +
                ", date=" + this.getDate() +
                ", indentify=" + indentify +
                '}';
    }
}
