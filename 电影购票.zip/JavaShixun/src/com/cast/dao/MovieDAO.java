package com.cast.dao;

import com.cast.bean.Movie;
import com.cast.bean.User;
import com.cast.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class MovieDAO {
    /**
     * 保存相关电影信息
     * @param movie
     * @return
     * @throws Exception
     */
    public boolean save(Movie movie) throws Exception {
        Connection conn= JDBCUtils.getConnect();
        //movie_name,movie_type,movie_time,movie_date,movie_price
        String sql="insert into movie(movie_name,movie_type,movie_num,movie_time,movie_date,movie_price) values(?,?,?,?,?,?)";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setString(1,movie.getMoviename());
        ps.setString(2,movie.getMovietype());
        ps.setInt(3,movie.getMovienum());
        ps.setInt(4,movie.getMovietime());
        ps.setDate(5, new java.sql.Date(movie.getMoviedate().getTime()));
        ps.setFloat(6,movie.getMovieprice());
        boolean flag=false;
        int rs=ps.executeUpdate();
        if(rs>0){
            flag=true;
        }
        JDBCUtils.closeJDBC(null,ps,conn);
        return flag;
    }

    /**查找所有电影信息
     *
     * @return
     * @throws Exception
     */
    public List<Movie> findAll() throws Exception {
        List<Movie> list=null;
        Connection conn=JDBCUtils.getConnect();
        String sql="select * from movie";
        PreparedStatement ps=conn.prepareStatement(sql);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
          if(list==null){
              list=new ArrayList<Movie>();
          }
            //movieid,moviename,movietype,movienum,movietime,moviedate,movieprice
          Movie movie=new Movie();
          movie.setMovieid(rs.getInt(1));
          movie.setMoviename(rs.getString(2));
          movie.setMovietype(rs.getString(3));
          movie.setMovienum(rs.getInt(4));
          movie.setMovietime(rs.getInt(5));
          movie.setMoviedate(rs.getDate(6));
          movie.setMovieprice(rs.getFloat(7));
          list.add(movie);
        }
        JDBCUtils.closeJDBC(rs,ps,conn);
        return list;
    }

    /**
     * 根据电影类型找电影
     * @param movietype
     * @return
     * @throws Exception
     */
    public List<Movie> findByType(String movietype) throws Exception {
        List<Movie> movielist=null;
        Connection conn=JDBCUtils.getConnect();
        String sql="select * from movie where movie_type=?";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setString(1,movietype);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            if(movielist==null){
                movielist=new ArrayList<>();
            }
            Movie movie=new Movie();
            movie.setMovieid(rs.getInt(1));
            movie.setMoviename(rs.getString(2));
            movie.setMovietype(rs.getString(3));
            movie.setMovienum(rs.getInt(4));
            movie.setMovietime(rs.getInt(5));
            movie.setMoviedate(rs.getDate(6));
            movie.setMovieprice(rs.getFloat(7));
            movielist.add(movie);
        }
        JDBCUtils.closeJDBC(rs,ps,conn);
        return movielist;
    }

    /**
     * 根据电影
     * @param mid
     * @return
     * @throws Exception
     */
    public Movie findById(int mid) throws Exception {
        Movie movie=null;
        Connection conn=JDBCUtils.getConnect();
        String sql="select * from movie where movie_id=?";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setInt(1,mid);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            movie=new Movie();
            movie.setMovieid(rs.getInt(1));
            movie.setMoviename(rs.getString(2));
            movie.setMovietype(rs.getString(3));
            movie.setMovienum(rs.getInt(4));
            movie.setMovietime(rs.getInt(5));
            movie.setMoviedate(rs.getDate(6));
            movie.setMovieprice(rs.getFloat(7));
        }
        JDBCUtils.closeJDBC(rs,ps,conn);
        return movie;
    }

    /**
     * 根据电影名称找电影
     * @param moviename
     * @return
     * @throws Exception
     */
    public Movie findByName(String moviename) throws Exception {
        Movie movie=null;
        Connection conn=JDBCUtils.getConnect();
        String sql="select * from movie where movie_name=?";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setString(1,moviename);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            movie=new Movie();
            movie.setMovieid(rs.getInt(1));
            movie.setMoviename(rs.getString(2));
            movie.setMovietype(rs.getString(3));
            movie.setMovienum(rs.getInt(4));
            movie.setMovietime(rs.getInt(5));
            movie.setMoviedate(rs.getDate(6));
            movie.setMovieprice(rs.getFloat(7));
        }
        JDBCUtils.closeJDBC(rs,ps,conn);
        return movie;
    }

    /**
     * 修改售卖票之后的相关信息
     * @param movie
     * @return
     * @throws Exception
     */
    public boolean updateMovieInfo(Movie movie) throws Exception {
        boolean flag=false;
        Connection conn=JDBCUtils.getConnect();
        String sql="update movie set movie_num=? where movie_id=?";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setInt(1,movie.getMovienum());
        ps.setInt(2,movie.getMovieid());
        int rs=ps.executeUpdate();
        if(rs>0){
            flag=true;
        }
        JDBCUtils.closeJDBC(null,ps,conn);
        return flag;
    }

    /**
     * 修改某一个电影的相关信息
     * @param movie
     * @return
     * @throws Exception
     */
    public boolean modifyMovieInfo(Movie movie) throws Exception {
       boolean flag=false;
       Connection conn=JDBCUtils.getConnect();
       String sql="update movie set movie_num=?,movie_price=? where movie_id=?";
       PreparedStatement ps=conn.prepareStatement(sql);
       ps.setInt(1,movie.getMovienum());
       ps.setFloat(2,movie.getMovieprice());
       ps.setInt(3,movie.getMovieid());
       int rs=ps.executeUpdate();
       if(rs>0){
           flag=true;
       }
       JDBCUtils.closeJDBC(null,ps,conn);
       return flag;
    }

    /**
     * 删除某个电影信息
     * @param movieid
     * @return
     * @throws Exception
     */
    public boolean deleteMovie(int movieid) throws Exception {
        boolean flag=false;
        Connection conn=JDBCUtils.getConnect();
        String sql="delete from movie where movie_id=?";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setInt(1,movieid);
        int rs=ps.executeUpdate();
        if(rs>0){
          flag=true;
        }
        return flag;
    }
}
