package com.cast.dao;

import com.cast.bean.Order;
import com.cast.bean.Salebean;
import com.cast.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.*;

public class OrderDAO {

    /**
     * 保存相关订单信息
     * @param order
     * @return
     * @throws Exception
     */
    public boolean save(Order order) throws Exception {
        boolean flag=false;
        Connection conn= JDBCUtils.getConnect();
        String sql="insert into book(username,movie_name,movie_type,movie_price,movie_num,total_price,order_time) values(?,?,?,?,?,?,?)";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setString(1,order.getUsername());
        ps.setString(2,order.getMoviename());
        ps.setString(3,order.getMovietype());
        ps.setFloat(4,order.getMovieprice());
        ps.setInt(5,order.getMovienum());
        ps.setFloat(6,order.getTotalprice());
        ps.setTimestamp(7,new Timestamp(new Date().getTime()));
        int rs=ps.executeUpdate();
        if(rs>0){
            flag=true;
        }
        JDBCUtils.closeJDBC(null,ps,conn);
        return flag;
    }

    /**
     * 查询所有订单信息
     * @return
     * @throws Exception
     */
    public List<Order> findAll() throws Exception {
        List<Order> list=null;
        Connection conn=JDBCUtils.getConnect();
        String sql="select * from book";
        PreparedStatement ps=conn.prepareStatement(sql);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            if(list==null){
                list=new ArrayList<Order>();
            }
            Order order=new Order();
            order.setOrderid(rs.getInt(1));
            order.setUsername(rs.getString(2));
            order.setMoviename(rs.getString(3));
            order.setMovietype(rs.getString(4));
            order.setMovieprice(rs.getFloat(5));
            order.setMovienum(rs.getInt(6));
            order.setTotalprice(rs.getFloat(7));
            order.setOrdertime(rs.getTimestamp(8));
            list.add(order);
        }
        JDBCUtils.closeJDBC(rs,ps,conn);
        return list;
    }

    /**
     * 根据用户名查询订单信息
     * @param username
     * @return
     * @throws Exception
     */
    public List<Order> findByName(String username) throws Exception {
        List<Order> list=null;
        Connection conn=JDBCUtils.getConnect();
        String sql="select * from book where username=?";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setString(1,username);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            if(list==null){
                list=new ArrayList<>();
            }
            Order order=new Order();
            order.setOrderid(rs.getInt(1));
            order.setUsername(rs.getString(2));
            order.setMoviename(rs.getString(3));
            order.setMovietype(rs.getString(4));
            order.setMovieprice(rs.getFloat(5));
            order.setMovienum(rs.getInt(6));
            order.setTotalprice(rs.getFloat(7));
            order.setOrdertime(rs.getTimestamp(8));
            list.add(order);

        }
        JDBCUtils.closeJDBC(rs,ps,conn);
        return list;
    }

    public Map<String,Float> sumByTypes() throws Exception {
        Map<String,Float> map=null;
        Connection conn=JDBCUtils.getConnect();
        String sql="select movie_type,round(SUM(total_price),2) from book group by movie_type";
        PreparedStatement ps=conn.prepareStatement(sql);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            if(map==null){
                map=new HashMap<>();
            }
            map.put(rs.getString(1),rs.getFloat(2));
        }
        JDBCUtils.closeJDBC(rs,ps,conn);
      return map;
    }

    /**
     * 根据电影类型统计销售量
     * @return
     * @throws Exception
     */
    public List<Salebean> sumByType() throws Exception {
        List<Salebean> list=null;
        Connection conn=JDBCUtils.getConnect();
        String sql="select movie_type,sum(movie_num),round(SUM(total_price),2) from book group by movie_type order by sum(total_price) desc";
        PreparedStatement ps=conn.prepareStatement(sql);
        ResultSet rs=ps.executeQuery();

        while(rs.next()){
            if(list==null){
                list=new ArrayList<>();
            }
            Salebean sb=new Salebean();
            sb.setMovietype(rs.getString(1));
            sb.setTotal_num(rs.getInt(2));
            sb.setTotalprice(rs.getFloat(3));
            list.add(sb);
        }
        JDBCUtils.closeJDBC(rs,ps,conn);
        return list;
    }

    /**
     * 统计所有销售量
     * @return
     * @throws Exception
     */
    public String sumAll() throws Exception {
        Connection conn=JDBCUtils.getConnect();
        String sql="select sum(movie_num),round(SUM(total_price),2) from book";
        PreparedStatement ps=conn.prepareStatement(sql);
        ResultSet rs=ps.executeQuery();
        String s="";
        while(rs.next()){
            s="总销售量为："+rs.getInt(1)+"票，产生的"+"所有的销售总额为："+rs.getFloat(2)+"元";
        }
        JDBCUtils.closeJDBC(rs,ps,conn);
        return s;
    }

    /**
     * 根据订单号查询订单信息
     * @param orderid
     * @return
     * @throws Exception
     */
    public Order findById(int orderid) throws Exception {
        Order order = null;
        Connection conn=JDBCUtils.getConnect();
        String sql="select * from book where order_id=?";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setInt(1,orderid);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            order=new Order();
            order.setOrderid(rs.getInt(1));
            order.setUsername(rs.getString(2));
            order.setMoviename(rs.getString(3));
            order.setMovietype(rs.getString(4));
            order.setMovieprice(rs.getFloat(5));
            order.setMovienum(rs.getInt(6));
            order.setTotalprice(rs.getFloat(7));
            order.setOrdertime(rs.getTimestamp(8));
        }
        JDBCUtils.closeJDBC(rs,ps,conn);
        return order;
    }

    /**
     * 修改相关订单信息
     * @param order_id
     * @param order
     * @return
     * @throws Exception
     */
    public boolean modifyOrderInfo(int order_id,Order order) throws Exception {
        boolean flag=false;
        Connection conn=JDBCUtils.getConnect();
        String sql="update book set movie_num=?,total_price=? where order_id=?";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setInt(1,order.getMovienum());
        ps.setFloat(2,order.getTotalprice());
        ps.setInt(3,order_id);
        int rs=ps.executeUpdate();
        if(rs>0){
            flag=true;
        }
        JDBCUtils.closeJDBC(null,ps,conn);
        return flag;
    }

    /**
     * 根据某个订单号查询订单
     * @param orderid
     * @return
     * @throws Exception
     */
    public boolean deleteOrder(int orderid) throws Exception {
        boolean flag=false;
        Connection conn=JDBCUtils.getConnect();
        String sql="delete from book where order_id=?";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setInt(1,orderid);
        int rs=ps.executeUpdate();
        if(rs>0){
            flag=true;
        }
        return flag;
    }

    /**
     * 根据传值的电影Id来找寻电影名称，并判断其是否包含在订单表中
     * @param movieid
     * @return
     * @throws Exception
     */
    public List<String> findByMName(int movieid) throws Exception {
        List<String> list=null;
        Connection conn=JDBCUtils.getConnect();
        String sql="select book.movie_name from book,movie where movie_id=? and book.movie_name=movie.movie_name";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setInt(1,movieid);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            if(list==null){
                list=new ArrayList<>();
            }
            list.add(rs.getString(1));
        }
        JDBCUtils.closeJDBC(rs,ps,conn);
        return list;
    }
}
