package com.cast.dao;

import com.cast.bean.User;
import com.cast.utils.JDBCUtils;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UserDAO {
    /**
     * 判断订单是否成功
     * @param user
     * @return
     * @throws Exception
     */
    public User login(User user) throws Exception {
        User user1 = null;
        String sql = "select * from user where username=? and password=?";
        Connection conn = JDBCUtils.getConnect();
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, user.getUsername());
        ps.setString(2, user.getPassword());
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            user1 = new User();
            user1.setUsername(rs.getString("username"));
            user1.setPassword(rs.getString("password"));
        }
        JDBCUtils.closeJDBC(rs, ps, conn);
        return user1;
    }

    /**
     * 判断账户是否已经存在
     * @param username
     * @return
     * @throws Exception
     */
    public boolean isExistUser(String username) throws Exception {
        boolean flag = false;
        Connection conn = JDBCUtils.getConnect();
        String sql = "select username from user where username=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, username);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            flag = true;
            break;
        }
        JDBCUtils.closeJDBC(rs, ps, conn);
        return flag;
    }

    /**
     * 保存相关用户信息
     * @param user
     * @return
     * @throws Exception
     */
    public boolean save(User user) throws Exception {
        boolean flag = false;
        //user_id,username,password,tel,balance,reg_time,indentify
        String sql = "insert into user(username,password,tel,balance,reg_time,indentify) values(?,?,?,?,?,?)";
        Connection conn = JDBCUtils.getConnect();
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, user.getUsername());
        ps.setString(2, user.getPassword());
        ps.setString(3, user.getTel());
        ps.setFloat(4, user.getBalance());
        ps.setTimestamp(5, new Timestamp(new Date().getTime()));
        ps.setInt(6, 1);
        int rs = ps.executeUpdate();
        if (rs > 0) {
            flag = true;
        }
        JDBCUtils.closeJDBC(null, ps, conn);
        return flag;
    }

    /**
     * 查询所有订单信息
     * @return
     * @throws Exception
     */
    public List<User> findAll() throws Exception {
        List<User> userList = null;
        Connection conn = JDBCUtils.getConnect();
        String sql = "select * from user";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            if (userList == null) {
                userList = new ArrayList<>();
            }
            User user = new User();
            user.setUserid(rs.getInt(1));
            user.setUsername(rs.getString(2));
            user.setPassword(rs.getString(3));
            user.setTel(rs.getString(4));
            user.setBalance(rs.getFloat(5));
            user.setDate(rs.getTimestamp(6));
            user.setIndentify(rs.getInt(7));
            userList.add(user);
        }
        return userList;
    }

    /**
     * 根据用户名查找用户
     * @param username
     * @return
     * @throws Exception
     */
    public List<User> findByname(String username) throws Exception {
        List<User> userList = null;
        Connection conn = JDBCUtils.getConnect();
        String sql = "select * from user where username=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, username);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            if (userList == null) {
                userList = new ArrayList<>();
            }
            User user = new User();
            user.setUserid(rs.getInt(1));
            user.setUsername(rs.getString(2));
            user.setPassword(rs.getString(3));
            user.setTel(rs.getString(4));
            user.setBalance(rs.getFloat(5));
            user.setDate(rs.getTimestamp(6));
            user.setIndentify(rs.getInt(7));
            userList.add(user);
        }
        JDBCUtils.closeJDBC(rs,ps,conn);
        return userList;
    }

    /**
     * 根据用户名查找信息
     * @param username
     * @return
     * @throws Exception
     */
    public User seekByname(String username) throws Exception {
        Connection conn = JDBCUtils.getConnect();
        String sql = "select * from user where username=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, username);
        ResultSet rs = ps.executeQuery();
        User user = null;
        while (rs.next()) {
            user = new User();
            user.setUserid(rs.getInt(1));
            user.setUsername(rs.getString(2));
            user.setPassword(rs.getString(3));
            user.setTel(rs.getString(4));
            user.setBalance(rs.getFloat(5));
            user.setDate(rs.getTimestamp(6));
            user.setIndentify(rs.getInt(7));
        }
        JDBCUtils.closeJDBC(rs,ps,conn);
        return user;

    }

    /**
     * 买票时，修改账户余额信息
     * @param user
     * @return
     * @throws Exception
     */
    public boolean updateUserInfo(User user) throws Exception {
        boolean flag=false;
        Connection conn=JDBCUtils.getConnect();
        String sql="update user set balance=? where username=?";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setFloat(1,user.getBalance());
        ps.setString(2,user.getUsername());
        int rs=ps.executeUpdate();
        if(rs>0){
            flag=true;
        }
        JDBCUtils.closeJDBC(null,ps,conn);
        return flag;
    }

    /**
     * 修改用户信息
     * @param u
     * @return
     * @throws Exception
     */
    public boolean modifyUserInfo(User u) throws Exception {
        boolean flag=false;
        User user=this.seekByname(u.getUsername());
        Connection conn=JDBCUtils.getConnect();
        String sql="update user set password=?,tel=?,balance=? where username=?";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setString(1,u.getPassword());
        ps.setString(2,u.getTel());
        ps.setFloat(3,u.getBalance()+user.getBalance());
        ps.setString(4,u.getUsername());
        int rs=ps.executeUpdate();
        if(rs>0){
            flag=true;
        }
        JDBCUtils.closeJDBC(null,ps,conn);
        return flag;
    }

    /**
     * 根据用户名删除某个用户
     * @param username
     * @return
     * @throws Exception
     */
    public boolean deleteUser(String username) throws Exception {
        boolean flag=false;
        Connection conn=JDBCUtils.getConnect();
        String sql="delete from user where username=?";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setString(1,username);
        int rs=ps.executeUpdate();
        if(rs>0){
            flag=true;
        }
        return flag;
    }

}
