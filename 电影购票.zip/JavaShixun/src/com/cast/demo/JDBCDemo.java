package com.cast.demo;

import com.cast.bean.Movie;
import com.cast.bean.Order;
import com.cast.bean.Salebean;
import com.cast.bean.User;
import com.cast.dao.MovieDAO;
import com.cast.dao.OrderDAO;
import com.cast.dao.UserDAO;
import com.cast.utils.JDBCUtils;

import java.lang.ref.PhantomReference;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class JDBCDemo {
    public static  void main(String[] args) throws Exception {
//        Connection conn= JDBCUtils.getConnect();
//        String sql="select * from user";
//        PreparedStatement ps=conn.prepareStatement(sql);
//        ResultSet rs=ps.executeQuery();
//        while(rs.next()){
//            System.out.print(rs.getString(1)+" ");
//            System.out.print(rs.getString(2)+" ");
//            System.out.print(rs.getString(3)+" ");
//            System.out.println(rs.getString(4));
//        }
//        JDBCUtils.closeJDBC(rs,ps,conn);
//        List<Order> list=new ArrayList<>();
//        OrderDAO ud=new OrderDAO();
//        list=ud.findAll();
//        for(Order u:list){
//            System.out.println(u);
//        }

//        Map<String,Float> map=ud.sumByType();
//        for (String in : map.keySet()) {
//            //map.keySet()返回的是所有key的值
//            Float str = map.get(in);//得到每个key多对用value的值
//            System.out.println(in + "     " + str);
//        }
//        List<Salebean> li=new ArrayList<>();
//        li=ud.sumByType();
//        for(Salebean i:li){
//            System.out.println(i);
//        }
//
//        User user=new User();
//        user.setUsername("spx");
//        user.setPassword("123456");
//        user.setTel("13974488888");
//        user.setBalance(20);
//        UserDAO ud=new UserDAO();
//        boolean flag=ud.modifyUserInfo(user);
//        System.out.println(flag);

        String username="spx";
        UserDAO ud=new UserDAO();
        boolean flag=ud.deleteUser(username);
        System.out.println(flag);


    }
}
