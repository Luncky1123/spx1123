package com.cast.servlet;

import com.cast.bean.User;
import com.cast.dao.UserDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username=request.getParameter("username");
        String password=request.getParameter("password");
        UserDAO ud=new UserDAO();
        User loginuser=new User();
        System.out.println("user"+username+"--"+password);
        loginuser.setUsername(username);
        loginuser.setPassword(password);
        User user=null;
        try {
            user=ud.login(loginuser);
            if(user==null){
                PrintWriter writer=response.getWriter();
                writer.write("<script>");
                writer.write("alert('账号或者密码错误！！！');");
                writer.write("window.location.href='login.html'");
                writer.write("</script>");
                writer.flush();
                writer.close();
            }else{
                response.sendRedirect("/JavaShixun/AdminHomePage.html");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
