package com.cast.servlet;

import com.cast.bean.Movie;
import com.cast.dao.MovieDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 添加保存电影操作
 */
@WebServlet("/MovieManagementServlet")
public class MovieManagementServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         request.setCharacterEncoding("utf-8");
         response.setContentType("text/html;charset=UTF-8");
         String moviename=request.getParameter("moviename");
         String movietype=request.getParameter("movietype");
         String movienum=request.getParameter("movienum");
         String movietime=request.getParameter("movietime");
         String year=request.getParameter("year");
         String month=request.getParameter("month");
         String day=request.getParameter("day");
         String movieprice=request.getParameter("movieprice");
         String datestr=year+"-"+month+"-"+day;
         Date date=new Date();
         try {
            date=new SimpleDateFormat("yyyy-MM-dd").parse(datestr);
         } catch (ParseException e) {
            e.printStackTrace();
         }
        Movie movie=new Movie();
        movie.setMoviename(moviename);
        movie.setMovietype(movietype);
        movie.setMovienum(Integer.valueOf(movienum));
        movie.setMovietime(Integer.valueOf(movietime));
        movie.setMoviedate(date);
        movie.setMovieprice(Float.valueOf(movieprice));
        MovieDAO md=new MovieDAO();
        try {
            boolean flag=md.save(movie);
            if(flag){
                PrintWriter writer=response.getWriter();
                writer.write("<script>");
                writer.write("alert('保存成功');");
                writer.write("</script>");
                writer.flush();
                writer.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
