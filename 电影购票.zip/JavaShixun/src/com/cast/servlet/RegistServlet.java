package com.cast.servlet;

import com.cast.bean.User;
import com.cast.dao.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/RegistServlet")
public class RegistServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         request.setCharacterEncoding("utf-8");
         response.setContentType("text/html;charset=UTF-8");
         PrintWriter writer=response.getWriter();
         String username=request.getParameter("username");
         String password=request.getParameter("password");
         String tel=request.getParameter("tel");
         String balancestr=request.getParameter("balance");
         String fun=request.getParameter("fun");
         if("checkusername".equals(fun)){
             UserDAO ud=new UserDAO();
             try {
                  boolean flag=ud.isExistUser(username);
                  if(flag){writer.print("no");
                  }else{
                      writer.print("yes");
                  }
                  writer.flush();
                  writer.close();
             } catch (Exception e) {
                 e.printStackTrace();
             }
         }

         float balance=Float.valueOf(balancestr);
            User user=new User();
            user.setUsername(username);
            user.setPassword(password);
            user.setTel(tel);
            user.setBalance(balance);
            UserDAO ud=new UserDAO();
        try {
            boolean flag1=ud.save(user);
            if(flag1){
                    writer=response.getWriter();
                    writer.write("<script>");
                    writer.write("alert('注册成功');");
                    writer.write("</script>");
                    writer.flush();
                    writer.close();
                }else{
                    writer=response.getWriter();
                    writer.write("<script>");
                    writer.write("alert('注册失败');");
                    writer.write("</script>");
                    writer.flush();
                    writer.close();
        } }catch (Exception e) {
            e.printStackTrace();
        }
    }
}
