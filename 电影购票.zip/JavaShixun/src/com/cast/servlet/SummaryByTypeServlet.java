package com.cast.servlet;

import com.cast.bean.Salebean;
import com.cast.dao.OrderDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/SummaryByTypeServlet")
public class SummaryByTypeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          request.setCharacterEncoding("utf-8");
          response.setContentType("text/html;charSet=utf-8");
          String type=request.getParameter("movietype");
          List<Salebean> list=null;
          String str;
          OrderDAO od=new OrderDAO();
        try {list=od.sumByType();
            str=od.sumAll();
            request.setAttribute("list", list);
            request.setAttribute("info",str);
            request.getRequestDispatcher("summaryAll.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
