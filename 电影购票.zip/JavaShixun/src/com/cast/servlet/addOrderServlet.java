package com.cast.servlet;

import com.cast.bean.Movie;
import com.cast.bean.Order;
import com.cast.bean.User;
import com.cast.dao.MovieDAO;
import com.cast.dao.OrderDAO;
import com.cast.dao.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/addOrderServlet")
public class addOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       request.setCharacterEncoding("utf-8");
       response.setContentType("text/html;charSet=utf-8");
       //username,movie_name,movie_type,movie_price,movie_num,total_price,order_time
       String movieid=request.getParameter("movieid");
       String moviename=request.getParameter("moviename");
       String movietype=request.getParameter("movietype");
       String movieprice=request.getParameter("movieprice");
       String ticket=request.getParameter("ticekt");
       String username=request.getParameter("username");
       UserDAO ud=new UserDAO();
       User user=null;
       OrderDAO od=new OrderDAO();
       Order order=new Order();
       MovieDAO md=new MovieDAO();
       Movie movie=null;
        try {
            user=ud.seekByname(username);
            if(user==null){
                PrintWriter writer = response.getWriter();
                writer.write("<script>");
                writer.write("alert('无法查询到该用户信息！');");
                writer.write("</script>");
                writer.flush();
                writer.close();
            }else{
                if(user.getBalance()-(Integer.valueOf(ticket)*Float.valueOf(movieprice))>=0.0){
                   // username,movie_name,movie_type,movie_price,movie_num,total_price,order_time
                    order.setUsername(username);
                    order.setMoviename(moviename);
                    order.setMovietype(movietype);
                    order.setMovieprice(Float.valueOf(movieprice));
                    order.setMovienum(Integer.valueOf(ticket));
                    order.setTotalprice(Integer.valueOf(ticket)*Float.valueOf(movieprice));
                    boolean flag3=od.save(order);

                    user.setBalance(user.getBalance()-(Integer.valueOf(ticket)*Float.valueOf(movieprice)));
                    boolean flag1=ud.updateUserInfo(user);

                    movie=md.findById(Integer.valueOf(movieid));
                    movie.setMovienum(movie.getMovienum()-Integer.valueOf(ticket));
                    boolean flag2=md.updateMovieInfo(movie);
                    if(flag2&&flag1&&flag3){
                        PrintWriter writer = response.getWriter();
                        writer.write("<script>");
                        writer.write("alert('购票成功');");
                        writer.write("</script>");
                        writer.flush();
                        writer.close();
                    }
                }else{
                    PrintWriter writer = response.getWriter();
                    writer.write("<script>");
                    writer.write("alert('该会员账户余额不足！！！');");
                    writer.write("</script>");
                    writer.flush();
                    writer.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
