package com.cast.servlet;

import com.cast.bean.Order;
import com.cast.dao.MovieDAO;
import com.cast.dao.OrderDAO;
import com.cast.dao.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/deleteMovieServlet")
public class deleteMovieServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         request.setCharacterEncoding("utf-8");
         response.setContentType("text/html;charSet=utf-8");
         String movieid=request.getParameter("mvid");
         System.out.println(movieid);
         OrderDAO od=new OrderDAO();
        try {
            List<String> list=od.findByMName(Integer.valueOf(movieid));
            if(list==null){
                MovieDAO md=new MovieDAO();
                boolean flag=md.deleteMovie(Integer.valueOf(movieid));
                if(flag){
                    PrintWriter writer=response.getWriter();
                    writer.write("<script>");
                    writer.write("alert('删除电影信息成功！');");
                    writer.write("</script>");
                    writer.flush();
                    writer.close();
                }
            }else{
                PrintWriter writer=response.getWriter();
                writer.write("<script>");
                writer.write("alert('此电影信息存在相关影票订单，不可删除！！！');");
                writer.write("</script>");
                writer.flush();
                writer.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
