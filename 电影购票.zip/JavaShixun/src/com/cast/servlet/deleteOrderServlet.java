package com.cast.servlet;

import com.cast.bean.Movie;
import com.cast.bean.Order;
import com.cast.bean.User;
import com.cast.dao.MovieDAO;
import com.cast.dao.OrderDAO;
import com.cast.dao.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/deleteOrderServlet")
public class deleteOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         request.setCharacterEncoding("utf-8");
         response.setContentType("text/html;charSet=utf-8");
         String orderid=request.getParameter("oid");
         OrderDAO od=new OrderDAO();
        try {
            Order order=od.findById(Integer.valueOf(orderid));
            String username=order.getUsername();
            String moviename=order.getMoviename();

            UserDAO ud=new UserDAO();
            User user=ud.seekByname(username);
            user.setBalance(user.getBalance()+order.getTotalprice());
            boolean flag1=ud.updateUserInfo(user);

            MovieDAO md=new MovieDAO();
            Movie movie=md.findByName(moviename);
            movie.setMovienum(movie.getMovienum()+order.getMovienum());
            boolean flag2=md.updateMovieInfo(movie);

            boolean flag3=od.deleteOrder(Integer.valueOf(orderid));
            if(flag1&&flag2&&flag3){
                PrintWriter writer=response.getWriter();
                writer.write("<script>");
                writer.write("alert('删除订单信息成功！');");
                writer.write("</script>");
                writer.flush();
                writer.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
