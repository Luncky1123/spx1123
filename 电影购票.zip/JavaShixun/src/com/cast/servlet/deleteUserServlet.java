package com.cast.servlet;

import com.cast.bean.Order;
import com.cast.dao.OrderDAO;
import com.cast.dao.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/deleteUserServlet")
public class deleteUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         request.setCharacterEncoding("utf-8");
         response.setContentType("text/html;charSet=utf-8");
         String username=request.getParameter("uname");
         OrderDAO od=new OrderDAO();
        try {
            List<Order> list=od.findByName(username);
            if(list==null){
                UserDAO ud=new UserDAO();
                boolean flag=ud.deleteUser(username);
                if(flag){
                    PrintWriter writer=response.getWriter();
                    writer.write("<script>");
                    writer.write("alert('删除用户信息成功！');");
                    writer.write("</script>");
                    writer.flush();
                    writer.close();
                }
            }else{
                PrintWriter writer=response.getWriter();
                writer.write("<script>");
                writer.write("alert('此用户存在相关影票订单，不可删除！！！');");
                writer.write("</script>");
                writer.flush();
                writer.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
