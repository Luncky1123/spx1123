package com.cast.servlet;

import com.cast.bean.Movie;
import com.cast.dao.MovieDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/modifyMovieServlet")
public class modifyMovieServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charSet=utf-8");
        String movieid=request.getParameter("movieid");
        String movienum=request.getParameter("movienum");
        String movieprice=request.getParameter("movieprice");
        Movie movie=new Movie();
        movie.setMovieid(Integer.valueOf(movieid));
        movie.setMovienum(Integer.valueOf(movienum));
        movie.setMovieprice(Float.valueOf(movieprice));
        MovieDAO md=new MovieDAO();
        try {
            boolean flag=md.modifyMovieInfo(movie);
            if(flag){
                PrintWriter writer=response.getWriter();
                writer.write("<script>");
                writer.write("alert('修改电影信息成功');");
                writer.write("</script>");
                writer.flush();
                writer.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
