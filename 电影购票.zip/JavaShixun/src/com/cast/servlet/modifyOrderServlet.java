package com.cast.servlet;

import com.cast.bean.Movie;
import com.cast.bean.Order;
import com.cast.bean.User;
import com.cast.dao.MovieDAO;
import com.cast.dao.OrderDAO;
import com.cast.dao.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/modifyOrderServlet")
public class modifyOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
           this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charSet=utf-8");
        String orderid=request.getParameter("orderid");
        String moviename=request.getParameter("moviename");
        String movienum=request.getParameter("movienum");
        String username=request.getParameter("username");
        String movieprice=request.getParameter("movieprice");
        OrderDAO od=new OrderDAO();
        try {
            Order order=od.findById(Integer.valueOf(orderid));
            int num=order.getMovienum()-Integer.valueOf(movienum);
            //判断影票的数量对比之前是增加还是减少，修改对应的账户信息和电影信息
            //1.增加
            if(num<0){
                boolean flag1=false,flag2=false,flag3=false;
                MovieDAO md=new MovieDAO();
                Movie movie=md.findByName(moviename);
                if(movie.getMovienum()>=Math.abs(num)){
                    movie.setMovienum(movie.getMovienum()-Math.abs(num));
                    flag1=md.updateMovieInfo(movie);
                    UserDAO ud=new UserDAO();
                    User user=ud.seekByname(username);
                    if(flag1&&(user.getBalance()-Float.valueOf(movieprice)*Math.abs(num))>=0){
                        user.setBalance(user.getBalance()-Float.valueOf(movieprice)*Math.abs(num));
                        flag2=ud.updateUserInfo(user);
                    }else{
                        PrintWriter writer=response.getWriter();
                        writer.write("<script>");
                        writer.write("alert('用户余额不足');");
                        writer.write("</script>");
                        writer.flush();
                        writer.close();
                    }
                    if(flag2){
                        order.setMovienum(Integer.valueOf(movienum));
                        order.setTotalprice(Integer.valueOf(movienum)*Float.valueOf(movieprice));
                        flag3=od.modifyOrderInfo(Integer.valueOf(orderid),order);
                        if(flag3){
                            PrintWriter writer=response.getWriter();
                            writer.write("<script>");
                            writer.write("alert('修改订单成功');");
                            writer.write("</script>");
                            writer.flush();
                            writer.close();

                        }
                    }
                }else{
                    PrintWriter writer=response.getWriter();
                    writer.write("<script>");
                    writer.write("alert('无多余电影票');");
                    writer.write("</script>");
                    writer.flush();
                    writer.close();
                }

            }else if(num>0){//减少，余额加差价，影票数量加差值
                boolean flag1=false,flag2=false,flag3=false;
                MovieDAO md=new MovieDAO();
                Movie movie=md.findByName(moviename);
                movie.setMovienum(movie.getMovienum()+num);
                flag1=md.updateMovieInfo(movie);
                UserDAO ud=new UserDAO();
                User user=ud.seekByname(username);
                user.setBalance(user.getBalance()+Float.valueOf(movieprice)*num);
                flag2=ud.updateUserInfo(user);
                order.setMovienum(Integer.valueOf(movienum));
                order.setTotalprice(Integer.valueOf(movienum)*Float.valueOf(movieprice));
                flag3=od.modifyOrderInfo(Integer.valueOf(orderid),order);
                if(flag3&&flag1&&flag2){
                    PrintWriter writer=response.getWriter();
                    writer.write("<script>");
                    writer.write("alert('修改订单成功');");
                    writer.write("</script>");
                    writer.flush();
                    writer.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
