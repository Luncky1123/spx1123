package com.cast.servlet;

import com.cast.bean.User;
import com.cast.dao.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/modifyUserServlet")
public class modifyUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       request.setCharacterEncoding("utf-8");
       response.setContentType("text/html;charSet=utf-8");
       User user=new User();
       String username=request.getParameter("username");
       String ischange=request.getParameter("change");
       String password="";
       if("yes".equals(ischange)){
           password=request.getParameter("newpassword");
       }else{
           password=request.getParameter("password");
       }
       String tel=request.getParameter("tel");
       String ischongzhi=request.getParameter("chongzhi");
       String balancestr="";
       float balance;
        if("yes".equals(ischongzhi)){
            balancestr=request.getParameter("balance");
            balance= Float.valueOf(balancestr);
        }else{
            balance=0;
        }
        user.setUsername(username);
        user.setPassword(password);
        user.setTel(tel);
        user.setBalance(balance);
        UserDAO ud=new UserDAO();
        try {
            boolean flag=ud.modifyUserInfo(user);
            if(flag){
                PrintWriter writer=response.getWriter();
                writer.write("<script>");
                writer.write("alert('修改用户信息成功');");
                writer.write("</script>");
                writer.flush();
                writer.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(username+"====="+ischange+"===="+password+"===="+tel+"---"+ischongzhi+"----"+balance);
    }
}
