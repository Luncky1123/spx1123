package com.cast.servlet;

import com.cast.bean.Order;
import com.cast.dao.OrderDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/orderSeekNameServlet")
public class orderSeekNameServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         request.setCharacterEncoding("utf-8");
         response.setContentType("text/html;charSet=utf-8");
         String username=request.getParameter("username");
         OrderDAO od=new OrderDAO();
         List<Order> list=null;
        try {
            list=od.findByName(username);
            if(list==null){
                PrintWriter writer=response.getWriter();
                writer.write("<script>");
                writer.write("alert('该用户没有产生任何订单！！');");
                writer.write("</script>");
                writer.flush();
                writer.close();
            }else{
                request.setAttribute("list",list);
                request.getRequestDispatcher("orderlist.jsp").forward(request,response);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
