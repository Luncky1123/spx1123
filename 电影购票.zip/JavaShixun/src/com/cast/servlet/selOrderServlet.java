package com.cast.servlet;

import com.cast.dao.MovieDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 显示所有可下单电影列表信息
 */
@WebServlet("/selOrderServlet")
public class selOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charSet=utf-8");
        List list=null;
        MovieDAO md=new MovieDAO();
        try {
            list=md.findAll();
            request.setAttribute("list",list);
            request.getRequestDispatcher("selorderlist.jsp").forward(request,response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
