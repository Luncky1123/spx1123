package com.cast.servlet;

import com.cast.bean.Order;
import com.cast.dao.OrderDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/showOrderServlet")
public class showOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
           this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          request.setCharacterEncoding("utf-8");
          response.setContentType("text/html;charSet=utf-8");
          String orderid=request.getParameter("oid");
          OrderDAO od=new OrderDAO();
        try {
            Order order=od.findById(Integer.valueOf(orderid));
            request.setAttribute("order",order);
            request.getRequestDispatcher("ordermodify.jsp").forward(request,response);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(orderid+"" + "**************");
    }
}
