package com.cast.servlet;

import com.cast.bean.User;
import com.cast.dao.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/showuInfoServlet")
public class showuInfoServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charSet=utf-8");
        String username=request.getParameter("uname");
        UserDAO ud=new UserDAO();
        User user=null;
        try {
            System.out.println(username);
            user=ud.seekByname(username);
            request.setAttribute("user",user);
            request.getRequestDispatcher("usermodify.jsp").forward(request,response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
