package com.cast.servlet;

import com.cast.bean.User;
import com.cast.dao.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/userSeekIdServlet")
public class userSeekIdServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("username");
        UserDAO ud = new UserDAO();
        List<User> list = null;
        try {
            list = ud.findByname(username);
            if (list != null) {
                request.setAttribute("list", list);
                request.getRequestDispatcher("userlists.jsp").forward(request, response);
            } else {
                PrintWriter writer = response.getWriter();
                writer.write("<script>");
                writer.write("alert('输入的用户名不存在！！');");
                writer.write("</script>");
                writer.flush();
                writer.close();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
