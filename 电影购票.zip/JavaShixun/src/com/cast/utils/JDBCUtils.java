package com.cast.utils;

import com.alibaba.druid.pool.DruidDataSourceFactory;

import javax.sql.DataSource;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class JDBCUtils {
    private Connection conn;

    /**
     *建立数据库链接
     * @return
     * @throws Exception
     */
    public static Connection getConnect() throws Exception {
        //读取配置文件
        InputStream in=Thread.currentThread().getContextClassLoader().getResourceAsStream("comfig/db.proprities");
        Properties properties=new Properties();
        properties.load(in);

        DataSource dataSource= DruidDataSourceFactory.createDataSource(properties);
        Connection conn=dataSource.getConnection();
        return conn;
    }

    /**
     * 关闭数据库链接
     * @param rs
     * @param stmt
     * @param conn
     */
    public static void closeJDBC(ResultSet rs, Statement stmt, Connection conn) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }
}
